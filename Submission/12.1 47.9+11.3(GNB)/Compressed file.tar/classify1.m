function [Y]=classify1(Model,X)
%MULTINOMIAL LOGISTIC REGRESSION
    Y=logistic_hog_classify(Model,X);
end