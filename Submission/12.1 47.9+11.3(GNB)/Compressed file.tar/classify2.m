function [Y] = classify2(Model, X)
    %Neural Network
   Y=nn_hog_classify(Model,X);
end